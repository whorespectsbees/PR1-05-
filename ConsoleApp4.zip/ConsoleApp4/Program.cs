﻿//задание 1
int a = 2;
int b = 3;
int result = (a + 4 * b) * (a - 3 + b) + a * a;
Console.WriteLine("Пример 1 при a=2,b=3:"+result);

double x = 1.7;
double result2 = Math.Pow(x + 1, 2) + 3 * (x + 1);
Console.WriteLine("Пример 2 при 1.7:" + result2);

double x2 = 3;
double result3 = Math.Pow(x2 + 1,2)  + 3 * (x2 +1);
Console.WriteLine("Пример 2 при 3:" + result3);

double x3 = -2.34;
double result4 = (Math.Abs(x3 - 5)- Math.Sin(x3))/3 + Math.Sqrt(Math.Pow(x3,2) + 2014) * Math.Cos(2 * x3);
Console.WriteLine("Пример 3 при -2.34:" + result4);


double x4 = 3.6;
double result5 = Math.Exp(x4 - 2) + Math.Abs(Math.Sin(x4)) - Math.Cos(1 / x4);
Console.WriteLine("Пример 4 при -2.34:" + result5);

Console.ReadKey();